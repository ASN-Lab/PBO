/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugas10;

/**
 *
 * @author m415d
 */
public class Makanan implements Pembayaran {
    private String namaProduk;
    private double harga;

    public Makanan(String namaProduk, double harga) {
        this.namaProduk = namaProduk;
        this.harga = harga;
    }

    @Override
    public double hitungPajak(double harga) {
        return harga * 0.05; // pajak 5%
    }

    public void tampilkanInfo() {
        double pajak = hitungPajak(harga);
        double total = harga + pajak;

        System.out.println("=== Produk Makanan ===");
        System.out.println("Nama Produk : " + namaProduk);
        System.out.println("Harga       : Rp " + harga);
        System.out.println("Pajak (5%)  : Rp " + pajak);
        System.out.println("Total Bayar : Rp " + total);
        System.out.println();
    }
}
