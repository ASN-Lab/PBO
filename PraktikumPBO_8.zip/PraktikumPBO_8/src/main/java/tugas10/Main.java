/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugas10;

/**
 *
 * @author m415d
 */
public class Main {
    public static void main(String[] args) {
        // Membuat objek Elektronik dan Makanan
        Elektronik laptop = new Elektronik("Laptop ASUS ROG", 15000000);
        Makanan snack = new Makanan("Keripik Kentang", 20000);

        // Menampilkan hasil perhitungan
        laptop.tampilkanInfo();
        snack.tampilkanInfo();
    }
}
