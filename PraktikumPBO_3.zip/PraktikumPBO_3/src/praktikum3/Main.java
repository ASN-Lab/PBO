/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum3;

/**
 *
 * @author ASN
 */
public class Main {
    public static void main(String[] args) {
        Hewan kucing = new Hewan("Kucing", 3);
        kucing.setNama("Kucing Anggora");
        kucing.setUmur(4);

        System.out.println("Informasi Hewan: ");
        System.out.println("Nama hewan: " + kucing.getNama());
        System.out.println("Umur hewan: " + kucing.getUmur() + " tahun");
        kucing.suara();
        
        System.out.println("\n--- Objek Anjing ---");
        Hewan anjing = new Hewan("Anjing", 5); // Membuat objek anjing
        System.out.println("Nama hewan: " + anjing.getNama());
        System.out.println("Umur hewan: " + anjing.getUmur() + " tahun");
        anjing.suara(); // Anjing juga bersuara
        anjing.berlari(); // Anjing berlari
    }
}
