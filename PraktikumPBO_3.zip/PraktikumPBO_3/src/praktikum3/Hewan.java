/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum3;

/**
 *
 * @author ASN
 */
public class Hewan {
    private String nama;
    private int umur;
    
    public void suara() {
    System.out.println("Hewan bersuara");
    }
    
    public void berlari() {
        System.out.println(nama + " sedang berlari.");
    }
    
    public void info() {
        System.out.println("Nama: " + getNama());
        System.out.println("Umur: " + getUmur() + " tahun");
    }
    
    public Hewan(String nama, int umur) {
    this.nama = nama;
    this.umur = umur;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public int getUmur() {
        return umur;
    }

    public void setUmur(int umur) {
        this.umur = umur;
    }
}