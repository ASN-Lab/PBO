/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Mobil;

/**
 *
 * @author ASN
 */
public class Main {
    public static void main(String[] args) {
        // Ciptakan objek mobil pertama
        Mobil mobil1 = new Mobil("Toyota", "Camry", 2020);

        // Ciptakan objek mobil kedua
        Mobil mobil2 = new Mobil("Honda", "Civic", 2022);

        System.out.println("--- Informasi Mobil 1 ---");
        mobil1.displayInfo();

        System.out.println("\n--- Informasi Mobil 2 ---");
        mobil2.displayInfo();
        
        System.out.println("\n--- Aksi Mobil ---");
        mobil1.startEngine();
        mobil2.startEngine();
        
        System.out.println("\n--- Perubahan Warna ---");
        mobil1.ubahWarna("Merah");
        mobil2.ubahWarna("Biru");
        System.out.println("\n--- Informasi Mobil Setelah Perubahan Warna ---");
        System.out.println("--- Informasi Mobil 1 ---");
        mobil1.displayInfo();
        System.out.println("\n--- Informasi Mobil 2 ---");
        mobil2.displayInfo();
    }
}
