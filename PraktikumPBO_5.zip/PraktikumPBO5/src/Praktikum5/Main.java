/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Praktikum5;

/**
 *
 * @author m415d
 */
public class Main {
    public static void main(String[] args) {
        // Bagian Hewan
        System.out.println("=== Informasi Hewan ===");
        Kucing kucing = new Kucing();
        kucing.nama = "Kitty";
        kucing.jenis = "Mamalia";
        kucing.tampilkanInfo();
        kucing.suara();

        System.out.println();
        Anjing anjing = new Anjing();
        anjing.nama = "Doggy";
        anjing.jenis = "Mamalia";
        anjing.tampilkanInfo();
        anjing.suara();

        // Bagian Kendaraan
        System.out.println("\n=== Informasi Kendaraan ===");
        Mobil mobil = new Mobil();
        mobil.nama = "Toyota Avanza";
        mobil.kecepatan = 180;
        mobil.jumlahRoda = 4;
        mobil.jumlahPintu = 4;
        mobil.tampilkanInfo();

        System.out.println();
        SepedaMotor motor = new SepedaMotor();
        motor.nama = "Yamaha R15";
        motor.kecepatan = 120;
        motor.jumlahRoda = 2;
        motor.jenisMesin = "4-Tak";
        motor.tampilkanInfo();
    }
}
