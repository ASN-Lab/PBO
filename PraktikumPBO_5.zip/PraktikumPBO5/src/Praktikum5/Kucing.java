/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Praktikum5;

/**
 *
 * @author m415d
 */
public class Kucing extends Hewan {
    @Override
    public void tampilkanInfo() {
        super.tampilkanInfo();
        System.out.println("Hewan ini adalah seekor kucing.");
    }

    @Override
    public void suara() {
        System.out.println("Kucing mengeong: Meoww...");
    }
}
