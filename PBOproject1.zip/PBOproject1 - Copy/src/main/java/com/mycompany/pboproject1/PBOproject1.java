/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pboproject1;

/**
 *
 * @author ASN
 */
public class PBOproject1 {

    public static void main(String[] args) {
        // Default output dari NetBeans
        System.out.println("Hello World!");
        System.out.println("==========================");

        // Biodata
        String nama   = "nama_kalian";
        String npm    = "NPM_kalian";
        String alamat = "alamat_kalian";
        String noHp   = "no_hp_kalian";

        System.out.println("• Nama   : " + nama);
        System.out.println("• NPM    : " + npm);
        System.out.println("• Alamat : " + alamat);
        System.out.println("• No_HP  : " + noHp);
    }
}
