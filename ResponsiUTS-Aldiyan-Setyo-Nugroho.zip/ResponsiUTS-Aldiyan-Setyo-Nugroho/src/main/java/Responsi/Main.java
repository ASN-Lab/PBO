/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Responsi;

/**
 *
 * @author m415d
 */
import Responsi.Produk.*;
import Responsi.Pegawai.*;

public class Main {
    public static void main(String[] args) {
        System.out.println("=== Output Produk ===");
        Elektronik laptop = new Elektronik("PT Teknologi", "Laptop", 9500000, 2);
        laptop.tampilkanInfo();

        System.out.println("\n=== Output Pegawai ===");
        PegawaiTetap pegawai1 = new PegawaiTetap("PT Teknologi", "Aldi", 5000000, 1000000);
        pegawai1.tampilkanInfo();

        System.out.println("\n=== Output Polimorfisme ===");
        Produk snack = new Makanan("PT Makanan", "Snack", 15000, "2025-10-3");
        snack.tampilkanInfo();

        System.out.println();
        Pegawai kontrak = new PegawaiKontrak("PT Teknologi", "Andi", 3000000, 12);
        kontrak.tampilkanInfo();
    }
}
