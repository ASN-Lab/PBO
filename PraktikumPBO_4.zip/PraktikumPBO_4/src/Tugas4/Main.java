/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas4;

/**
 *
 * @author ASN
 */
public class Main {
    public static void main(String[] args) {
        // Membuat objek Pekerja
        Pekerja pekerja = new Pekerja("Andi", 30, "Programmer", 10000000);
        
        // Menampilkan informasi pekerja menggunakan toString()
        System.out.println("Informasi Pekerja:");
        System.out.println(pekerja.toString());
        
        // Mengubah nama pekerja menggunakan setter
        pekerja.setNama("Budi");
        
        // Menampilkan ulang informasi pekerja setelah nama diubah
        System.out.println("\nSetelah mengubah nama:");
        System.out.println(pekerja.toString());
        
        // Mencoba akses langsung atribut nama, usia, dan gaji
        System.out.println(pekerja.nama);    // Error: nama private di Manusia
        System.out.println("Usia (akses langsung): " + pekerja.usia); // Bisa karena protected dan Pekerja subclass Manusia
        System.out.println("Pekerjaan (akses langsung): " + pekerja.pekerjaan); // public, bisa diakses langsung
        System.out.println(pekerja.gaji);    // Error: gaji private di Pekerja
    }
}