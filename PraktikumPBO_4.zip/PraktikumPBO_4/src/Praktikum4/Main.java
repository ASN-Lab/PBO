/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Praktikum4;

/**
 *
 * @author ASN
 */
public class Main {
//    public static void main(String[] args) {
//        // Membuat objek Kendaraan
//        Kendaraan mobil = new Kendaraan("Toyota", "Avanza", 2020);
//        
//        // Menampilkan data menggunakan getter
//        System.out.println("Merek: " + mobil.getMerek());
//        System.out.println("Model: " + mobil.getModel());
//        System.out.println("Tahun: " + mobil.getTahun());
//    }
    
//        public static void main(String[] args) {
//            // Membuat objek Kendaraan
//            Kendaraan mobil = new Kendaraan("Toyota", "Avanza", 2020);
//
//            // Menampilkan data awal
//            System.out.println("Data awal:");
//            System.out.println("Merek: " + mobil.getMerek());
//            System.out.println("Model: " + mobil.getModel());
//            System.out.println("Tahun: " + mobil.getTahun());
//
//            // Mengubah data menggunakan setter
//            mobil.setMerek("Honda");
//            mobil.setModel("Civic");
//            mobil.setTahun(2022);
//
//            // Menampilkan data setelah diubah
//            System.out.println("\nData setelah diubah:");
//            System.out.println("Merek: " + mobil.getMerek());
//            System.out.println("Model: " + mobil.getModel());
//            System.out.println("Tahun: " + mobil.getTahun());
//    }
    
        public static void main(String[] args) {
        // Membuat objek Kendaraan
        Kendaraan kendaraan = new Kendaraan("Motor", 120, "Bensin");
        System.out.println("Informasi Kendaraan:");
        kendaraan.tampilkanInfoKendaraan();
        
        System.out.println();
        
        // Membuat objek Mobil
        Mobil mobil = new Mobil("Toyota Avanza", 180, "Diesel", 4);
        System.out.println("Informasi Mobil:");
        mobil.tampilkanInfoKendaraan(); // method dari superclass Kendaraan
        mobil.tampilkanInfoMobil();      // method khusus di kelas Mobil
    }
}
