/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Praktikum4;

/**
 *
 * @author ASN
 */
public class Kendaraan {
//    private String merek;
//    private String model;
//    private int tahun;
//    
//    //COnstructor
//    public Kendaraan(String merek, String model, int tahun) {
//        this.merek = merek;
//        this.model = model;
//        this.tahun = tahun;
//    }
//
//    //Getter & Setter untuk merek
//    public String getMerek() {
//        return merek;
//    }
//
//    public void setMerek(String merek) {
//        this.merek = merek;
//    }
//
//    //Getter & Setter untuk model
//    public String getModel() {
//        return model;
//    }
//
//    public void setModel(String model) {
//        this.model = model;
//    }
//
//    //Getter & Setter untuk tahun
//    public int getTahun() {
//        return tahun;
//    }
//
//    public void setTahun(int tahun) {
//        this.tahun = tahun;
//    }
    
    private String nama;
    protected int kecepatanMaks;
    public String jenisMesin;
    
    //Constructor
    public Kendaraan(String nama, int kecepatanMaks, String jenisMesin) {
        this.nama = nama;
        this.kecepatanMaks = kecepatanMaks;
        this.jenisMesin = jenisMesin;
    }

    //Getter & Setter untuk nama
    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }
    
    //Method public untuk menampilkan informasi kendaraan
    public void tampilkanInfoKendaraan() {
        System.out.println("Nama Kendaraan: " + nama);
        System.out.println("Kecepatan Maksimum: " + kecepatanMaks + " Km/h");
        System.out.println("Jenis Mesin: " + jenisMesin);
    }
    
}
