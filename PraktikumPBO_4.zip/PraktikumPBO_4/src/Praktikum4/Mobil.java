/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Praktikum4;

/**
 *
 * @author ASN
 */
public class Mobil extends Kendaraan {
    private int jumlahPintu;
    
    //Constructor
    public Mobil (String nama, int kecepatanMaks, String jenisMesin, int jumlahPintu) {
        super (nama, kecepatanMaks, jenisMesin);
        this.jumlahPintu = jumlahPintu;
    }
    
    //Method untuk menampilkan informasi mobil
    public void tampilkanInfoMobil() {
        System.out.println("Kecepatan maksimum mobil: " + kecepatanMaks + " Km/h");
        System.out.println("Jumlah pintu: " + jumlahPintu);
    }
}
