/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas6;

/**
 *
 * @author m415d
 */
public class Main {
    public static void main(String[] args) {
        KeranjangBelanja keranjang = new KeranjangBelanja();

        Produk buku = new Buku("Java Programming", 100000);
        Produk elektronik = new Elektronik("Smartphone", 3000000);
        Produk pakaian = new Pakaian("Jaket Hoodie", 250000);

        keranjang.tambahProduk(buku);
        keranjang.tambahProduk(elektronik);
        keranjang.tambahProduk(pakaian);

        System.out.println("=== Daftar Produk dalam Keranjang ===");
        keranjang.tampilkanDaftarProduk();

        System.out.println("\nTotal Harga Setelah Diskon: " + keranjang.hitungTotal());
    }
}
