/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum9;

/**
 *
 * @author m415d
 */
public class Main {
    public static void main(String[] args) {
        Kendaraan Mobil = new Mobil();
        Kendaraan Sepeda = new Sepeda();
        Kendaraan Motor = new Motor();
        
        Mobil.berjalan();
        Mobil.info();
        
        Sepeda.berjalan();
        Sepeda.info();
        
        Motor.berjalan();
        Motor.info();
    }
}
