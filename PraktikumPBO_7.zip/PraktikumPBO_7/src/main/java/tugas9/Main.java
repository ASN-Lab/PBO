/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugas9;

/**
 *
 * @author m415d
 */
public class Main {
        public static void main(String[] args) {
        Hewan Kucing = new Kucing();
        Hewan Anjing = new Anjing();
                
        Kucing.suara();
        Kucing.info();
        
        Anjing.suara();
        Anjing.info();
    }
}
