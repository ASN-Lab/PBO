/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugas9;

/**
 *
 * @author m415d
 */
abstract class Hewan {
    String namaHewan;
    abstract void suara();
    
    void info() {
        System.out.println("Hewan " + namaHewan + " yang mengeluarkan suara");
        System.out.println("");
    }
}
