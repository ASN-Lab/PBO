/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugas9;

/**
 *
 * @author m415d
 */
public class Anjing extends Hewan {
    @Override
    void suara() {
        System.out.println("Suara: Guk Guk");
    }
}
