/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package perpustakaan;

/**
 *
 * @author m415d
 */
public class Perpustakaan {
    private String namaPerpustakaan;
    private Buku[] daftarBuku;
    private int jumlahBuku;

    public Perpustakaan(String namaPerpustakaan, int kapasitas) {
        this.namaPerpustakaan = namaPerpustakaan;
        this.daftarBuku = new Buku[kapasitas];
        this.jumlahBuku = 0;
    }

    public void tambahBuku(String judul, Pengarang pengarang) {
        if (jumlahBuku < daftarBuku.length) {
            daftarBuku[jumlahBuku] = new Buku(judul, pengarang);
            jumlahBuku++;
        } else {
            System.out.println("Kapasitas perpustakaan penuh!");
        }
    }

    public void tampilkanInfo() {
        System.out.println("=== " + namaPerpustakaan + " ===");
        if (jumlahBuku == 0) {
            System.out.println("Belum ada buku di perpustakaan.");
        } else {
            for (int i = 0; i < jumlahBuku; i++) {
                daftarBuku[i].infoBuku();
            }
        }
    }
}