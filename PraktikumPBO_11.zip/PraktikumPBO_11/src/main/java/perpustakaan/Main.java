/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package perpustakaan;

/**
 *
 * @author m415d
 */
public class Main {
    public static void main(String[] args) {
        Pengarang pengarang1 = new Pengarang("Andrea Hirata");
        Pengarang pengarang2 = new Pengarang("Tere Liye");
        Pengarang pengarang3 = new Pengarang("Dewi Lestari");

        Perpustakaan perpus = new Perpustakaan("Perpustakaan Kota Malang", 5);

        perpus.tambahBuku("Laskar Pelangi", pengarang1);
        perpus.tambahBuku("Hujan", pengarang2);
        perpus.tambahBuku("Perahu Kertas", pengarang3);

        perpus.tampilkanInfo();
    }
}